import { posts, postsInsertSchema } from "@/server/db/schemas/posts";
import { consola } from "consola";

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  const parsed = postsInsertSchema.safeParse(body);

  if (!parsed.success) {
    consola.error("Error creating post:", parsed.error);
    throw createError({
      statusCode: 422,
      statusMessage: "Bad Request",
      data: parsed.error,
    });
  }

  try {
    const db = useDb();
    const [newPost] = await db.insert(posts).values(parsed.data).returning();
    consola.info("Post created successfully:", newPost);
    return { data: newPost };
  } catch (err: any) {
    consola.error("DB insert failed:", err);
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
    });
  }
});
