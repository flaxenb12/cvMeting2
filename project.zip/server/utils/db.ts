import { drizzle } from "drizzle-orm/node-postgres";

export function useDb() {
  return drizzle(process.env.DATABASE_URL as string);
}
